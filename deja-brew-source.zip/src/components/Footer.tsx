import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, MapPin, Clock } from "lucide-react";
import logo from "@/assets/deja-brew-logo.png";

export function Footer() {
  return (
    <footer className="bg-espresso text-sand mt-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8 py-16 grid gap-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <img src={logo} alt="Deja Brew" className="h-14 w-14 rounded-full" />
            <span className="font-display text-3xl tracking-wider">DEJA BREW</span>
          </div>
          <p className="mt-5 max-w-md text-sand/70 leading-relaxed">
            Sun-soaked coffee on the Durban promenade. Brewed for surfers, runners,
            and anyone who likes the smell of espresso mixed with sea salt.
          </p>
        </div>

        <div>
          <h4 className="font-display tracking-widest text-sm text-sun">VISIT</h4>
          <p className="mt-4 flex items-start gap-2 text-sand/80">
            <MapPin className="size-4 mt-1 shrink-0 text-sunset" />
            <span>130 Lower Marine Parade<br />South Beach, Durban</span>
          </p>
          <p className="mt-3 flex items-start gap-2 text-sand/80">
            <Clock className="size-4 mt-1 shrink-0 text-sunset" />
            <span>Mon–Sun · 5:30am – 6pm</span>
          </p>
        </div>

        <div>
          <h4 className="font-display tracking-widest text-sm text-sun">EXPLORE</h4>
          <ul className="mt-4 space-y-2">
            <li><Link to="/menu" className="text-sand/80 hover:text-sun">Menu</Link></li>
            <li><Link to="/about" className="text-sand/80 hover:text-sun">Our Story</Link></li>
            <li><Link to="/visit" className="text-sand/80 hover:text-sun">Visit</Link></li>
            <li><Link to="/contact" className="text-sand/80 hover:text-sun">Contact</Link></li>
          </ul>
          <div className="mt-5 flex gap-3">
            <a href="#" aria-label="Instagram" className="p-2 rounded-full bg-sand/10 hover:bg-sunset transition-colors"><Instagram className="size-4" /></a>
            <a href="#" aria-label="Facebook" className="p-2 rounded-full bg-sand/10 hover:bg-sunset transition-colors"><Facebook className="size-4" /></a>
          </div>
        </div>
      </div>
      <div className="border-t border-sand/10">
        <div className="mx-auto max-w-7xl px-5 md:px-8 py-5 text-xs text-sand/50 flex flex-wrap justify-between gap-2">
          <span>© {new Date().getFullYear()} Deja Brew. All rights reserved.</span>
          <span>Brewed with salt air on the South Beach promenade.</span>
        </div>
      </div>
    </footer>
  );
}
