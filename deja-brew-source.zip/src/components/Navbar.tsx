import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import logo from "@/assets/deja-brew-logo.png";

const links = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/about", label: "Story" },
  { to: "/visit", label: "Visit" },
  { to: "/contact", label: "Contact" },
] as const;

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="mx-auto max-w-7xl px-5 md:px-8 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <img src={logo} alt="Deja Brew logo" className="h-12 w-12 rounded-full" />
          <span className="font-display text-2xl tracking-wider text-foreground">DEJA BREW</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="font-display tracking-widest text-sm text-foreground/80 hover:text-foreground transition-colors"
              activeProps={{ className: "text-accent" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label.toUpperCase()}
            </Link>
          ))}
        </nav>

        <Link
          to="/visit"
          className="hidden md:inline-flex items-center bg-sunrise text-espresso font-display tracking-widest text-sm px-5 py-2.5 rounded-full shadow-warm hover:scale-105 transition-transform"
        >
          FIND US
        </Link>

        <button
          className="md:hidden p-2 text-foreground"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <nav className="md:hidden border-t border-border bg-background px-5 py-4 flex flex-col gap-4">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className="font-display tracking-widest text-base text-foreground"
              activeProps={{ className: "text-accent" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label.toUpperCase()}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
