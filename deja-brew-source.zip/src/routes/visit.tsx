import { createFileRoute } from "@tanstack/react-router";
import { Clock, MapPin, Phone, Sunrise } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/visit")({
  head: () => ({
    meta: [
      { title: "Visit — Deja Brew, 130 Lower Marine Parade, Durban" },
      { name: "description", content: "Find Deja Brew at 130 Lower Marine Parade, South Beach Durban. Open daily from 5:30am — right on the promenade." },
      { property: "og:title", content: "Visit Deja Brew — South Beach Durban" },
      { property: "og:description", content: "130 Lower Marine Parade. Open daily from 5:30am." },
      { property: "og:url", content: "/visit" },
    ],
  }),
  component: VisitPage,
});

function VisitPage() {
  return (
    <SiteLayout>
      <section className="bg-background pt-20 pb-12">
        <div className="mx-auto max-w-7xl px-5 md:px-8 grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <span className="font-display tracking-widest text-sunset text-sm">FIND THE WINDOW</span>
            <h1 className="mt-3 font-display text-6xl md:text-7xl text-balance">
              On the promenade. Right on the sand.
            </h1>
            <p className="mt-5 text-foreground/75 leading-relaxed max-w-lg">
              We're a walk-up coffee window facing the Indian Ocean — two
              minutes from the surf, right on the running path.
            </p>

            <div className="mt-8 grid gap-4">
              <Info icon={MapPin} title="ADDRESS" body="130 Lower Marine Parade,\nSouth Beach, Durban, 4001" />
              <Info icon={Clock} title="HOURS" body="Mon – Fri · 5:30am – 6pm\nSat – Sun · 5:30am – 7pm" />
              <Info icon={Phone} title="GIVE US A SHOUT" body="+27 (0)31 000 0000\nhello@dejabrew.co.za" />
              <Info icon={Sunrise} title="BEST TIME" body="Sunrise — coffee tastes better when it's still pink." />
            </div>
          </div>

          <div className="rounded-3xl overflow-hidden shadow-warm border border-border aspect-square lg:aspect-auto lg:h-[640px]">
            <iframe
              title="Deja Brew location map"
              src="https://www.google.com/maps?q=130+Lower+Marine+Parade,+South+Beach,+Durban&output=embed"
              className="w-full h-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      <section className="bg-warm py-20">
        <div className="mx-auto max-w-7xl px-5 md:px-8 grid md:grid-cols-3 gap-6">
          {[
            { h: "BEFORE YOUR RUN", b: "Single shot, takeaway. We'll have it on the counter while you stretch." },
            { h: "AFTER YOUR SURF", b: "Order a Surfer Smoothie at the window. Bring sandy feet — we don't mind." },
            { h: "PARKING & WALK-UP", b: "Street parking on Lower Marine. Or come on foot, by bike, or barefoot." },
          ].map((c) => (
            <div key={c.h} className="bg-card rounded-2xl p-6 border border-border">
              <h3 className="font-display text-2xl">{c.h}</h3>
              <p className="mt-2 text-muted-foreground leading-relaxed">{c.b}</p>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}

function Info({ icon: Icon, title, body }: { icon: typeof MapPin; title: string; body: string }) {
  return (
    <div className="flex gap-4 rounded-2xl bg-card p-5 border border-border">
      <div className="size-11 shrink-0 rounded-full bg-sunrise grid place-items-center">
        <Icon className="size-5 text-espresso" />
      </div>
      <div>
        <h3 className="font-display tracking-widest text-sm">{title}</h3>
        <p className="mt-1 text-foreground/80 whitespace-pre-line">{body}</p>
      </div>
    </div>
  );
}
