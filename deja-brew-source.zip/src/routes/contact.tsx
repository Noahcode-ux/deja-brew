import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Instagram, Mail, Phone, Send } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Deja Brew" },
      { name: "description", content: "Get in touch with Deja Brew on the Durban promenade. Bookings, catering, or just to say hi." },
      { property: "og:title", content: "Contact — Deja Brew" },
      { property: "og:description", content: "Bookings, catering, or just to say hi." },
      { property: "og:url", content: "/contact" },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sending, setSending] = useState(false);

  return (
    <SiteLayout>
      <section className="bg-background py-20">
        <div className="mx-auto max-w-6xl px-5 md:px-8 grid lg:grid-cols-2 gap-14">
          <div>
            <span className="font-display tracking-widest text-sunset text-sm">SAY HI</span>
            <h1 className="mt-3 font-display text-6xl md:text-7xl text-balance">
              Drop us a line.
            </h1>
            <p className="mt-5 text-foreground/75 leading-relaxed">
              Catering, private events, or just want to tell us your order
              before you arrive? We'll get back to you within a day.
            </p>

            <div className="mt-8 grid gap-4">
              <a href="mailto:hello@dejabrew.co.za" className="flex items-center gap-4 rounded-2xl bg-card p-5 border border-border hover:shadow-warm transition-shadow">
                <Mail className="size-5 text-sunset" />
                <span className="font-display tracking-wide">hello@dejabrew.co.za</span>
              </a>
              <a href="tel:+27310000000" className="flex items-center gap-4 rounded-2xl bg-card p-5 border border-border hover:shadow-warm transition-shadow">
                <Phone className="size-5 text-sunset" />
                <span className="font-display tracking-wide">+27 (0)31 000 0000</span>
              </a>
              <a href="#" className="flex items-center gap-4 rounded-2xl bg-card p-5 border border-border hover:shadow-warm transition-shadow">
                <Instagram className="size-5 text-sunset" />
                <span className="font-display tracking-wide">@dejabrew</span>
              </a>
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSending(true);
              setTimeout(() => {
                setSending(false);
                toast.success("Thanks! We'll get back to you soon.");
                (e.target as HTMLFormElement).reset();
              }, 600);
            }}
            className="bg-card rounded-3xl p-8 border border-border shadow-warm"
          >
            <h2 className="font-display text-3xl">SEND A MESSAGE</h2>
            <div className="mt-6 grid gap-4">
              <Field label="Your name" name="name" type="text" required />
              <Field label="Email" name="email" type="email" required />
              <div>
                <label className="block font-display tracking-widest text-xs mb-2">MESSAGE</label>
                <textarea
                  name="message"
                  required
                  rows={5}
                  className="w-full rounded-xl bg-background border border-border px-4 py-3 focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <button
                type="submit"
                disabled={sending}
                className="inline-flex items-center justify-center gap-2 bg-sunrise text-espresso font-display tracking-widest px-6 py-3.5 rounded-full shadow-warm hover:scale-[1.02] transition-transform disabled:opacity-60"
              >
                {sending ? "SENDING…" : <>SEND <Send className="size-4" /></>}
              </button>
            </div>
          </form>
        </div>
      </section>
    </SiteLayout>
  );
}

function Field({ label, name, type, required }: { label: string; name: string; type: string; required?: boolean }) {
  return (
    <div>
      <label className="block font-display tracking-widest text-xs mb-2">{label.toUpperCase()}</label>
      <input
        name={name}
        type={type}
        required={required}
        className="w-full rounded-xl bg-background border border-border px-4 py-3 focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}
