import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import surfImg from "@/assets/surfboards.jpg";
import baristaImg from "@/assets/barista-pour.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story — Deja Brew" },
      { name: "description", content: "How a tiny walk-up window on Durban's South Beach became the promenade's unofficial meeting point." },
      { property: "og:title", content: "Our Story — Deja Brew" },
      { property: "og:description", content: "A walk-up window for surfers and runners on Durban's South Beach." },
      { property: "og:url", content: "/about" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout>
      <section className="bg-background pt-20 pb-16">
        <div className="mx-auto max-w-4xl px-5 md:px-8 text-center">
          <span className="font-display tracking-widest text-sunset text-sm">SINCE THE FIRST SUNRISE</span>
          <h1 className="mt-3 font-display text-6xl md:text-8xl text-balance">
            A coffee shop with sand in its shoes.
          </h1>
          <p className="mt-6 text-lg text-foreground/75 leading-relaxed">
            Deja Brew was built for the people already on the promenade —
            the dawn patrol surfers, the sunrise runners, the dog-walkers, the
            grandmothers, the kids on bicycles. We're a window, a counter,
            and a few stools facing the sea.
          </p>
        </div>
      </section>

      <section className="bg-background pb-20">
        <div className="mx-auto max-w-7xl px-5 md:px-8 grid md:grid-cols-2 gap-6">
          <img src={surfImg} alt="Surfboards leaning outside the shop" width={1600} height={1200} loading="lazy" className="rounded-3xl object-cover w-full aspect-[4/3]" />
          <img src={baristaImg} alt="Barista pouring milk" width={1280} height={1600} loading="lazy" className="rounded-3xl object-cover w-full aspect-[4/3]" />
        </div>
      </section>

      <section className="bg-warm py-20">
        <div className="mx-auto max-w-4xl px-5 md:px-8 grid gap-10">
          {[
            { h: "BREW WARM, BREW BRIGHT", b: "We roast on the lighter side of medium — chocolate notes up front, citrus on the finish, never bitter. The kind of cup that wakes you up without shouting." },
            { h: "FOR THE PROMENADE", b: "Most of our customers are wearing wetsuits, running tights, or both. The menu is built around that — fast service, real fuel, takeaway-first." },
            { h: "LOCAL, LOUD, FRIENDLY", b: "Beans roasted in KZN. Milk from a Midlands dairy. Music a little too loud before 7am. Sorry. Not sorry." },
          ].map((s) => (
            <div key={s.h} className="border-l-4 border-sunset pl-6">
              <h2 className="font-display text-3xl md:text-4xl">{s.h}</h2>
              <p className="mt-3 text-foreground/80 leading-relaxed">{s.b}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-espresso text-sand py-20">
        <div className="mx-auto max-w-3xl px-5 md:px-8 text-center">
          <h2 className="font-display text-5xl md:text-6xl">
            Come find the window.
          </h2>
          <p className="mt-4 text-sand/80">
            We're at 130 Lower Marine Parade, right on the South Beach
            promenade. Open from sunrise, every day.
          </p>
          <Link
            to="/visit"
            className="mt-8 inline-flex items-center bg-sunrise text-espresso font-display tracking-widest px-7 py-3.5 rounded-full shadow-warm hover:scale-105 transition-transform"
          >
            DIRECTIONS
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
