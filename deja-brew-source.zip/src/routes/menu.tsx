import { createFileRoute } from "@tanstack/react-router";
import { Leaf } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Deja Brew Durban" },
      { name: "description", content: "Espresso, iced coffee, smoothies and a kitchen built for surfers and runners on the Durban promenade." },
      { property: "og:title", content: "Menu — Deja Brew" },
      { property: "og:description", content: "Espresso, iced coffee, smoothies and kitchen." },
      { property: "og:url", content: "/menu" },
    ],
  }),
  component: MenuPage,
});

const sections = [
  {
    title: "ESPRESSO BAR",
    blurb: "Pulled fresh, all day.",
    items: [
      { name: "Espresso", price: "R32", note: "Single or double, on request." },
      { name: "Macchiato", price: "R38", note: "Espresso, dollop of milk." },
      { name: "Cortado", price: "R42", note: "Equal parts milk and espresso." },
      { name: "Promenade Flat White", price: "R45", note: "Our house standard." },
      { name: "Cappuccino", price: "R48", note: "Foam crown, cocoa dust." },
      { name: "Latte", price: "R50", note: "Long, smooth, easy." },
      { name: "Mocha", price: "R55", note: "Espresso, cocoa, milk." },
      { name: "Americano", price: "R38", note: "Double shot, hot water." },
    ],
  },
  {
    title: "COLD & ICED",
    blurb: "For when the sun's already up.",
    items: [
      { name: "Iced Coffee", price: "R52", note: "Double shot, milk, ice." },
      { name: "Iced Chocolate", price: "R55", note: "Cocoa, cold milk, whipped cream." },
    ],
  },
  {
    title: "SMOOTHIES",
    blurb: "Fuel for surf-outs and post-runs.",
    items: [
      { name: "Surfer Smoothie", price: "R72", note: "Banana, oats, peanut butter, milk." },
      { name: "Runner's Recovery", price: "R72", note: "Cacao, dates, almond milk, salt.", vegan: true },
    ],
  },
  {
    title: "KITCHEN",
    blurb: "Real food, made fresh on the promenade.",
    items: [
      { name: "Toasted Sandwiches", price: "R85", note: "Cheese, tomato, ham — pick your combo." },
      { name: "Full English Breakfast", price: "R125", note: "Eggs, bacon, sausage, beans, toast." },
      { name: "Plate of Chips", price: "R55", note: "Hand-cut, sea salt, aioli.", vegan: true },
      { name: "Muffins", price: "R38", note: "Baked daily — ask for today's flavour." },
      { name: "Cake Slices", price: "R52", note: "Carrot, chocolate, lemon — rotates." },
      { name: "Scones", price: "R45", note: "Warm, with jam and cream." },
      { name: "French Toast", price: "R88", note: "Brioche, cinnamon, maple, berries." },
      { name: "Omelets", price: "R95", note: "Three eggs, pick three fillings." },
      { name: "Avocado Toast", price: "R85", note: "Sourdough, smashed avo, chilli, lime.", vegan: true },
    ],
  },
];

function MenuPage() {
  return (
    <SiteLayout>
      <section className="bg-sunrise text-espresso">
        <div className="mx-auto max-w-7xl px-5 md:px-8 py-20 md:py-28">
          <span className="font-display tracking-widest text-sm">THE MENU</span>
          <h1 className="mt-3 font-display text-6xl md:text-8xl leading-[0.9]">
            BREWED FOR<br />THE PROMENADE.
          </h1>
          <p className="mt-5 max-w-xl text-espresso/80">
            Prices in ZAR. Plant-based milks (oat, almond, soy) +R8. Add an
            extra shot for R12. Look for the <span className="inline-flex items-center gap-1 rounded-full bg-espresso/10 px-1.5 py-0.5 text-[10px] font-bold tracking-widest"><Leaf className="size-2.5" /> VG</span> badge for vegan items.
          </p>
        </div>
      </section>

      <section className="bg-background py-20">
        <div className="mx-auto max-w-5xl px-5 md:px-8 grid gap-16">
          {sections.map((s) => (
            <div key={s.title}>
              <div className="border-b border-border pb-3">
                <h2 className="font-display text-3xl md:text-4xl">{s.title}</h2>
                <p className="mt-1 text-muted-foreground text-sm">{s.blurb}</p>
              </div>
              <ul className="mt-5 grid md:grid-cols-2 gap-x-12 gap-y-5">
                {s.items.map((i) => (
                  <li key={i.name}>
                    <div className="flex items-baseline gap-2">
                      <span className="font-display tracking-wide text-base text-foreground whitespace-nowrap inline-flex items-baseline gap-1.5">
                        {i.name}
                        {"vegan" in i && i.vegan && (
                          <span
                            title="Vegan"
                            aria-label="Vegan"
                            className="inline-flex items-center gap-1 rounded-full bg-[oklch(0.78_0.15_140)]/20 text-[oklch(0.42_0.12_140)] px-1.5 py-0.5 text-[9px] font-bold tracking-widest"
                          >
                            <Leaf className="size-2.5" /> VG
                          </span>
                        )}
                      </span>
                      <span className="flex-1 border-b border-dotted border-border translate-y-[-3px]" />
                      <span className="text-xs font-medium text-muted-foreground tabular-nums whitespace-nowrap">
                        {i.price}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground/80 leading-snug">{i.note}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
