import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Coffee, MapPin, Waves } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { WaveDivider } from "@/components/WaveDivider";
import logo from "@/assets/deja-brew-logo.png";
import heroImg from "@/assets/hero-promenade.jpg";
import flatlayImg from "@/assets/coffee-flatlay.jpg";
import baristaImg from "@/assets/barista-pour.jpg";
import surfImg from "@/assets/surfboards.jpg";
import sunsetImg from "@/assets/sunset-ocean.jpg";
import surfboardsSandImg from "@/assets/surfboards-sand.jpg";
import beachAerialImg from "@/assets/beach-aerial.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Deja Brew — Coffee on the Durban Promenade" },
      { name: "description", content: "Surf. Run. Sip. Repeat. Warm, sun-soaked coffee on Lower Marine Parade, South Beach Durban." },
      { property: "og:title", content: "Deja Brew — Coffee on the Durban Promenade" },
      { property: "og:description", content: "Surf. Run. Sip. Repeat. Warm coffee on the South Beach promenade." },
      { property: "og:url", content: "/" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <img
          src={heroImg}
          alt="Surfers and runners on the Durban promenade at sunrise"
          width={1920}
          height={1280}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-espresso/40 via-espresso/30 to-espresso/80" />

        <div className="relative mx-auto max-w-7xl px-5 md:px-8 pt-24 pb-32 md:pt-32 md:pb-44 text-sand">
          <div className="max-w-2xl animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-sand/30 bg-sand/10 backdrop-blur px-4 py-1.5 text-xs font-display tracking-widest">
              <Waves className="size-3.5 text-sun" /> SOUTH BEACH · DURBAN
            </span>
            <h1 className="mt-6 font-display text-6xl md:text-8xl leading-[0.9] text-balance">
              SURF. RUN.<br />
              <span className="bg-sunrise bg-clip-text text-transparent">SIP. REPEAT.</span>
            </h1>
            <p className="mt-6 max-w-lg text-lg text-sand/85 leading-relaxed">
              Espresso pulled to the rhythm of the Indian Ocean. Step off the
              promenade for a flat white, a smoothie, and a few minutes of sun.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 bg-sunrise text-espresso font-display tracking-widest px-7 py-3.5 rounded-full shadow-warm hover:scale-105 transition-transform"
              >
                SEE THE MENU <ArrowRight className="size-4" />
              </Link>
              <Link
                to="/visit"
                className="inline-flex items-center gap-2 bg-sand/10 backdrop-blur border border-sand/30 text-sand font-display tracking-widest px-7 py-3.5 rounded-full hover:bg-sand/20 transition-colors"
              >
                FIND THE SHOP
              </Link>
            </div>
          </div>
        </div>

        <div className="text-background relative">
          <WaveDivider />
        </div>
      </section>

      {/* INFO STRIP */}
      <section className="bg-background">
        <div className="mx-auto max-w-7xl px-5 md:px-8 -mt-8 grid gap-4 md:grid-cols-3">
          {[
            { icon: MapPin, title: "WALK-UP WINDOW", body: "130 Lower Marine Parade, on the promenade." },
            { icon: Coffee, title: "OPEN EARLY", body: "Daily from 5:30am — perfect for sunrise sessions." },
            { icon: Waves, title: "TWO MINUTES TO SAND", body: "Closer to the surf than your wax." },
          ].map((c) => (
            <div key={c.title} className="bg-card rounded-2xl p-6 shadow-warm border border-border">
              <c.icon className="size-6 text-accent" />
              <h3 className="mt-3 font-display tracking-widest text-base">{c.title}</h3>
              <p className="mt-1 text-muted-foreground text-sm leading-relaxed">{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED */}
      <section className="bg-background py-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8 grid lg:grid-cols-2 gap-14 items-center">
          <div>
            <span className="font-display tracking-widest text-sunset text-sm">SIGNATURE POURS</span>
            <h2 className="mt-3 font-display text-5xl md:text-6xl text-balance">
              Coffee built for<br />salt-air mornings.
            </h2>
            <p className="mt-5 text-foreground/75 leading-relaxed max-w-lg">
              We roast warm and bright — chocolate, citrus, a little sea breeze.
              Every cup is dialled in for the kind of day that starts before
              the lifeguards arrive.
            </p>
            <div className="mt-8 grid sm:grid-cols-2 gap-3">
              {[
                { name: "PROMENADE FLAT WHITE", price: "R45" },
                { name: "ICED COFFEE", price: "R52" },
                { name: "AVOCADO TOAST", price: "R85" },
                { name: "FULL ENGLISH", price: "R125" },
              ].map((d) => (
                <div key={d.name} className="rounded-xl border border-border bg-card p-4 hover:shadow-warm hover:-translate-y-0.5 transition-all flex items-baseline gap-2">
                  <h3 className="font-display tracking-wider text-base">{d.name}</h3>
                  <span className="flex-1 border-b border-dotted border-border translate-y-[-3px]" />
                  <span className="text-xs font-medium text-muted-foreground tabular-nums">{d.price}</span>
                </div>
              ))}
            </div>
            <Link
              to="/menu"
              className="mt-8 inline-flex items-center gap-2 text-foreground font-display tracking-widest text-sm border-b-2 border-sunset pb-1"
            >
              SEE THE FULL MENU <ArrowRight className="size-4" />
            </Link>
          </div>

          <div className="relative">
            <img
              src={flatlayImg}
              alt="Flat white coffee on a sandy boardwalk"
              width={1280}
              height={1280}
              loading="lazy"
              className="rounded-3xl shadow-warm aspect-square object-cover"
            />
            <div className="absolute -bottom-6 -left-6 hidden md:flex items-center gap-3 bg-sunrise text-espresso px-5 py-3 rounded-full shadow-warm">
              <img src={logo} alt="" className="size-9 rounded-full" />
              <span className="font-display tracking-widest text-sm">BREWED ON THE BEACH</span>
            </div>
          </div>
        </div>
      </section>

      {/* SPLIT BAND */}
      <section className="bg-espresso text-sand">
        <div className="mx-auto max-w-7xl px-5 md:px-8 py-20 grid lg:grid-cols-2 gap-12 items-center">
          <img
            src={baristaImg}
            alt="Barista pouring milk into a coffee cup"
            width={1280}
            height={1600}
            loading="lazy"
            className="rounded-3xl object-cover aspect-[4/5] w-full shadow-warm"
          />
          <div>
            <span className="font-display tracking-widest text-sun text-sm">THE LOCAL</span>
            <h2 className="mt-3 font-display text-5xl md:text-6xl text-balance">
              A walk-up window with sand at the door.
            </h2>
            <p className="mt-5 text-sand/80 leading-relaxed">
              Deja Brew started as a tiny window for the dawn patrol. Now it's
              the unofficial meeting point on the South Beach stretch — surfers
              waxing boards, runners catching breath, locals catching up.
            </p>
            <Link
              to="/about"
              className="mt-8 inline-flex items-center gap-2 bg-sunrise text-espresso font-display tracking-widest px-6 py-3 rounded-full shadow-warm hover:scale-105 transition-transform"
            >
              OUR STORY <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* BEACH GALLERY */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <span className="font-display tracking-widest text-sunset text-sm">OUR BACKYARD</span>
            <h2 className="mt-3 font-display text-5xl md:text-6xl text-balance">
              Sun, salt, and the South Beach stretch.
            </h2>
          </div>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <img src={sunsetImg} alt="Pink and orange sunset over the Indian Ocean" width={1600} height={1280} loading="lazy" className="rounded-2xl object-cover aspect-[3/4] w-full row-span-2 md:row-span-2 col-span-2 md:col-span-2 h-full" />
            <img src={surfboardsSandImg} alt="Colorful surfboards in the sand" width={1600} height={1280} loading="lazy" className="rounded-2xl object-cover aspect-square w-full" />
            <img src={beachAerialImg} alt="Aerial view of Durban beach at sunset" width={1600} height={1280} loading="lazy" className="rounded-2xl object-cover aspect-square w-full" />
            <img src={surfImg} alt="Surfboards leaning at the coffee window" width={1600} height={1200} loading="lazy" className="rounded-2xl object-cover aspect-square w-full" />
            <img src={heroImg} alt="Surfers and runners on the promenade" width={1920} height={1280} loading="lazy" className="rounded-2xl object-cover aspect-square w-full" />
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
